# Crypto Portfolio Tracker (Flask + SQLite)

## Overview
Simple portfolio tracker that fetches live prices from CoinGecko and shows portfolio value.
Built with Flask, SQLite (SQLAlchemy), and Flask-Login for authentication.

## Quickstart (local)
1. Create and activate a virtualenv:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Run the app:
   ```bash
   python app.py
   ```
3. Open http://127.0.0.1:5000 in your browser.
4. Register a user, add coins by CoinGecko ID (e.g., `bitcoin`, `ethereum`) and amounts.

## Deploy
A `Dockerfile` is included for easy deployment to Render, Railway, or other services.

## Notes
- This starter project is intentionally simple so you can extend it:
  - Add price history, charts, or user settings
  - Improve caching, pagination, and input validation
  - Replace coin id input with a searchable dropdown (fetch /coins/list from CoinGecko)
