from flask import Flask, render_template, redirect, url_for, request, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from db import db
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import requests, time
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///portfolio.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Simple caching for CoinGecko responses
_cache = {'ts': 0, 'data': {}}
CACHE_TTL = 30  # seconds

with app.app_context():
    from models import User, Holding

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def fetch_prices(ids):
    # ids: list of coin ids like ['bitcoin','ethereum']
    now = time.time()
    if now - _cache['ts'] < CACHE_TTL and all(i in _cache['data'] for i in ids):
        return {i: _cache['data'][i] for i in ids if i in _cache['data']}
    url = 'https://api.coingecko.com/api/v3/simple/price'
    params = {'ids': ','.join(ids), 'vs_currencies': 'usd', 'include_24hr_change': 'true'}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    data = r.json()
    # update cache
    _cache['ts'] = now
    _cache['data'].update(data)
    return data

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        email = request.form['email'].strip()
        password = request.form['password']
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'warning')
            return redirect(url_for('register'))
        user = User(username=username, email=email,
                    password_hash=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        flash('Registration successful — please log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].strip()
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Logged in successfully', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid credentials', 'danger')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    holdings = Holding.query.filter_by(user_id=current_user.id).all()
    ids = list({h.coin_id for h in holdings})
    prices = {}
    if ids:
        try:
            prices = fetch_prices(ids)
        except Exception as e:
            flash('Price fetch failed: ' + str(e), 'warning')
    total_value = 0.0
    portfolio = []
    for h in holdings:
        p = prices.get(h.coin_id, {}).get('usd', None)
        change = prices.get(h.coin_id, {}).get('usd_24h_change', None)
        value = (p * h.amount) if p is not None else None
        if value:
            total_value += value
        portfolio.append({'id': h.id, 'coin_id': h.coin_id, 'amount': h.amount, 'price': p, 'change': change, 'value': value})
    return render_template('dashboard.html', portfolio=portfolio, total_value=total_value)

@app.route('/add', methods=['POST'])
@login_required
def add():
    coin_id = request.form.get('coin_id','').strip().lower()
    try:
        amount = float(request.form.get('amount', '0'))
    except:
        flash('Invalid amount', 'warning')
        return redirect(url_for('dashboard'))
    if not coin_id or amount <= 0:
        flash('Enter a valid coin id and amount', 'warning')
        return redirect(url_for('dashboard'))
    h = Holding(user_id=current_user.id, coin_id=coin_id, amount=amount)
    db.session.add(h)
    db.session.commit()
    flash(f'Added {amount} {coin_id} to your portfolio', 'success')
    return redirect(url_for('dashboard'))

@app.route('/remove/<int:hid>', methods=['POST'])
@login_required
def remove(hid):
    h = Holding.query.get(hid)
    if not h or h.user_id != current_user.id:
        flash('Not found or unauthorized', 'danger')
        return redirect(url_for('dashboard'))
    db.session.delete(h)
    db.session.commit()
    flash('Holding removed', 'info')
    return redirect(url_for('dashboard'))

@app.route('/api/prices')
@login_required
def api_prices():
    ids = request.args.get('ids','')
    ids = [i.strip().lower() for i in ids.split(',') if i.strip()]
    if not ids:
        return jsonify({})
    try:
        data = fetch_prices(ids)
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # create DB if missing
    if not os.path.exists('portfolio.db'):
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)
